// DOM object selector
const paperContainerTag = 'div.gs_r.gs_or.gs_scl'
const titleTag = 'h3 > a'

document.addEventListener('click', function(event) {
  // Identify the clicked element
  let clickedElement = event.target;
  console.log(clickedElement);
  console.log(clickedElement.closest('div#gsc_oci_title'))

  // Find the ancestor div with the specific class
  let paperContainer = clickedElement.closest(paperContainerTag);
  let authorContainer = clickedElement.closest('td.gsc_a_t')
  if (paperContainer) {
    let titleText = paperContainer.querySelector(titleTag).textContent;
    if (titleText) {
      console.log(titleText);
    }

    chrome.storage.local.get({ searchLogs: [] }, function (result) {
      let searchLogs = result.searchLogs;
      let searchAction = {
          logtype: "paper",
          title: titleText,
          query: '',
          yearStart: '',
          yearEnd: '',
          citedBy: '',
          cluster: '',
          authorID: '',
          timestamp: new Date().toISOString()
      };
      searchLogs.push(searchAction);
      chrome.storage.local.set({ searchLogs: searchLogs });
      console.log(searchLogs[length(searchAction)])
      
  });
  }else if(authorContainer){
    let titleText = paperContainer.querySelector('a').textContent;
    if (titleText) {
      console.log(titleText);
    }

    chrome.storage.local.get({ searchLogs: [] }, function (result) {
      let searchLogs = result.searchLogs;
      let searchAction = {
          logtype: "paper",
          title: titleText,
          query: '',
          yearStart: '',
          yearEnd: '',
          citedBy: '',
          cluster: '',
          authorID: '',
          timestamp: new Date().toISOString()
      };
      searchLogs.push(searchAction);
      chrome.storage.local.set({ searchLogs: searchLogs });
      console.log(searchLogs[length(searchAction)])
      
  });
  }
}, true);
